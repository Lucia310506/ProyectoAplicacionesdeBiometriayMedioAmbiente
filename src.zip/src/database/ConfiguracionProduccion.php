

<?php
return [
    'host' => 'localhost',
    'base' => 'ldiamur_mediciones',
    'usuario' => 'ldm',
    'password' => 'Drac@rys26'
];
