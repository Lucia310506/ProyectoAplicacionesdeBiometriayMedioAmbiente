

<?php
/*
 * Fichero: ConfiguracionProduccion.php
 * Autor: Lucía Díaz Murcia
 * Descripción: Credenciales locales del entorno seleccionado.
 * Fecha: 2026-09-25
 * Copyright (c) 2026 Lucía Díaz Murcia
 * Aportación: crear el archivo y hacerlo funcional
 */
return [
    'host' => 'localhost',
    'base' => 'ldiamur_mediciones',
    'usuario' => 'ldm',
    'password' => 'Drac@rys26'
];
