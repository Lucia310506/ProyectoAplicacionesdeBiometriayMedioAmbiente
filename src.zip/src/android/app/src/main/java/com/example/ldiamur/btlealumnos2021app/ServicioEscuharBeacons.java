/*
 * Fichero: ServicioEscuharBeacons.java
 * Autor: Lucía Díaz Murcia
 * Descripción: Servicio en segundo plano que escucha beacons y publica mediciones.
 * Fecha: 2026-09-25
 * Copyright (c) 2026 Lucía Díaz Murcia
 */
package com.example.ldiamur.btlealumnos2021app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.core.content.ContextCompat;

import java.util.Collections;
import java.util.Arrays;
import java.util.List;

// Escucha los anuncios BLE aunque la actividad ya no esté visible.
public class ServicioEscuharBeacons extends Service {

    public static final String ACCION_INICIAR =
            "com.example.ldiamur.btlealumnos2021app.INICIAR_ESCANEO";
    public static final String ACCION_BUSCAR_BEACON_PRUEBA =
            "com.example.ldiamur.btlealumnos2021app.BUSCAR_BEACON_PRUEBA";
    public static final String ACCION_RESULTADO_BEACON_PRUEBA =
            "com.example.ldiamur.btlealumnos2021app.RESULTADO_BEACON_PRUEBA";
    public static final String EXTRA_BEACON_ENCONTRADO = "beacon_encontrado";
    private static final String ETIQUETA_LOG = ">>>>";
    private static final String NOMBRE_BEACON = "LuciaGTI";
    private static final String CANAL_ID = "escucha_beacons";
    private static final int ID_NOTIFICACION = 1001;
    private static final int TIPO_BEACON_PRUEBA = 14;
    private static final int VALOR_BEACON_PRUEBA = 0x5A3C;
    private static final byte[] UUID_BEACON_PROYECTO = new byte[]{
            'E', 'P', 'S', 'G', '-', 'G', 'T', 'I', '-', 'P', 'R', 'O', 'Y', '-', '3', 'A'
    };
    private static final long DURACION_BUSQUEDA_PRUEBA_MS = 10000;

    private BluetoothLeScanner elEscanner;
    private ScanCallback callbackDelEscaneo;
    private int ultimoTipoMedida = -1;
    private int ultimoContador = -1;
    private boolean modoBusquedaPrueba = false;
    private boolean beaconPruebaEncontrado = false;
    private final Handler manejador = new Handler(Looper.getMainLooper());
    private final Runnable finBusquedaPrueba = this::finalizarBusquedaBeaconPrueba;


    @Override
    /*
     * --------------------
     *  onCreate()
     * Prepara las notificaciones y el escáner del servicio.
     * --------------------
     */
    public void onCreate() {
        super.onCreate();
        crearCanalNotificacion();
        iniciarPrimerPlano();
        prepararEscaner();
    }

    @Override
    /*
     * --------------------
     * intent: Intent, flags: N, id: N --> onStartCommand() --> N
     * Inicia la escucha y mantiene el servicio activo.
     * --------------------
     */
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACCION_BUSCAR_BEACON_PRUEBA.equals(intent.getAction())) {
            iniciarBusquedaBeaconPrueba();
        } else {
            iniciarEscaneo();
        }
        return START_STICKY;
    }

    /*
     * --------------------
     * --> iniciarBusquedaBeaconPrueba() -->
     * Escanea durante diez segundos y comunica si recibió el beacon centinela.
     * --------------------
     */
    private void iniciarBusquedaBeaconPrueba() {
        modoBusquedaPrueba = true;
        beaconPruebaEncontrado = false;
        if (callbackDelEscaneo != null) detenerEscaneo();
        iniciarEscaneo();
        if (callbackDelEscaneo != null) {
            manejador.removeCallbacks(finBusquedaPrueba);
            manejador.postDelayed(finBusquedaPrueba, DURACION_BUSQUEDA_PRUEBA_MS);
            Log.i("TEST_BEACON", "Buscando UUID del proyecto, tipo 14 y valor 0x5A3C");
        }
    }

    /*
     * --------------------
     * --> finalizarBusquedaBeaconPrueba() -->
     * Detiene el escaneo temporal y publica el resultado a la actividad.
     * --------------------
     */
    private void finalizarBusquedaBeaconPrueba() {
        if (!modoBusquedaPrueba) return;
        detenerEscaneo();
        modoBusquedaPrueba = false;
        Log.i("TEST_BEACON", beaconPruebaEncontrado
                ? "RESULTADO: beacon de prueba encontrado"
                : "RESULTADO: no se encontró el beacon de prueba");
        Intent resultado = new Intent(ACCION_RESULTADO_BEACON_PRUEBA);
        resultado.setPackage(getPackageName());
        resultado.putExtra(EXTRA_BEACON_ENCONTRADO, beaconPruebaEncontrado);
        sendBroadcast(resultado);
        if (!beaconPruebaEncontrado) stopSelf();
    }

    /*
     * --------------------
     * prepararEscaner() -->
     * Obtiene el escáner BLE o detiene el servicio si no hay Bluetooth.
     * --------------------
     */
    private void prepararEscaner() {
        BluetoothAdapter adaptador = BluetoothAdapter.getDefaultAdapter();
        if (adaptador == null) {
            Log.e(ETIQUETA_LOG, "El dispositivo no dispone de Bluetooth BLE");
            stopSelf();
            return;
        }
        elEscanner = adaptador.getBluetoothLeScanner();
    }

    /*
     * --------------------
     *  tengoPermisoEscaneo() --> B
     * Comprueba el permiso requerido por la versión Android.
     * --------------------
     */
    private boolean tengoPermisoEscaneo() {
        String permiso = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                ? Manifest.permission.BLUETOOTH_SCAN
                : Manifest.permission.ACCESS_FINE_LOCATION;
        return ContextCompat.checkSelfPermission(this, permiso) == PackageManager.PERMISSION_GRANTED;
    }

    /*
     * --------------------
     * --> iniciarEscaneo() -->
     * Configura el filtro GTI-3A y arranca el escaneo BLE.
     * --------------------
     */
    private void iniciarEscaneo() {
        if (elEscanner == null || !tengoPermisoEscaneo()) {
            Log.e(ETIQUETA_LOG, "No se puede iniciar el escaneo: falta Bluetooth o permiso");
            return;
        }
        if (callbackDelEscaneo != null) {
            return;
        }

        callbackDelEscaneo = new ScanCallback() {
            @Override
            /*
             * --------------------
             * tipo: N, resultado: ScanResult --> onScanResult() -->
             * Entrega cada anuncio recibido al analizador de beacons.
             * --------------------
             */
            public void onScanResult(int callbackType, ScanResult resultado) {
                super.onScanResult(callbackType, resultado);
                procesarBeacon(resultado);
            }

            @Override
            /*
             * --------------------
             * resultados: ScanResult[] --> onBatchScanResults() -->
             * Procesa todos los anuncios entregados en lote.
             * --------------------
             */
            public void onBatchScanResults(List<ScanResult> resultados) {
                super.onBatchScanResults(resultados);
                for (ScanResult resultado : resultados) {
                    procesarBeacon(resultado);
                }
            }

            @Override
            /*
             * --------------------
             * error: N --> onScanFailed() -->
             * Registra el error comunicado por el escáner BLE.
             * --------------------
             */
            public void onScanFailed(int errorCode) {
                super.onScanFailed(errorCode);
                Log.e(ETIQUETA_LOG, "Error al escanear beacons: " + errorCode);
            }
        };

        ScanFilter filtro = modoBusquedaPrueba
                ? new ScanFilter.Builder().setManufacturerData(0x004c,
                        new byte[]{0x02, 0x15}, new byte[]{(byte) 0xff, (byte) 0xff}).build()
                : new ScanFilter.Builder().setDeviceName(NOMBRE_BEACON).build();
        ScanSettings ajustes = new ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .build();

        elEscanner.startScan(Collections.singletonList(filtro), ajustes, callbackDelEscaneo);
        Log.d(ETIQUETA_LOG, "Servicio: escuchando beacons " + NOMBRE_BEACON);
    }

    /*
     * --------------------
     * resultado: ScanResult --> procesarBeacon() -->
     * Valida y decodifica el tipo, contador y valor del anuncio.
     * --------------------
     */
    private void procesarBeacon(ScanResult resultado) {
        if (resultado.getScanRecord() == null || resultado.getScanRecord().getBytes().length < 30) {
            return;
        }

        BluetoothDevice dispositivoBluetooth = resultado.getDevice();
        byte[] bytes = resultado.getScanRecord().getBytes();
        int rssi = resultado.getRssi();
        TramaIBeacon trama = new TramaIBeacon(bytes);

        int major = Utilidades.bytesToInt(trama.getMajor());
        int tipoMedida = major >> 8;
        int contador = major & 0xff;
        int valor = Utilidades.bytesToInt(trama.getMinor());
        if (modoBusquedaPrueba) {
            if (trama.getiBeaconType() == 0x02
                    && Arrays.equals(trama.getUUID(), UUID_BEACON_PROYECTO)
                    && tipoMedida == TIPO_BEACON_PRUEBA
                    && valor == VALOR_BEACON_PRUEBA) {
                beaconPruebaEncontrado = true;
                Log.i("TEST_BEACON", "OK: beacon de prueba recibido; contador=" + contador
                        + ", major=" + major + ", minor=0x5A3C");
                manejador.removeCallbacks(finBusquedaPrueba);
                manejador.post(finBusquedaPrueba);
            }
            return;
        }

        // Se conserva el registro detallado original para poder inspeccionar
        // cada beacon desde Logcat, aunque ahora lo genere el servicio.
        Log.d(ETIQUETA_LOG, " ****************************************************");
        Log.d(ETIQUETA_LOG, " ****** DISPOSITIVO DETECTADO BTLE ****************** ");
        Log.d(ETIQUETA_LOG, " ****************************************************");
        Log.d(ETIQUETA_LOG, " nombre = " + dispositivoBluetooth.getName());
        Log.d(ETIQUETA_LOG, " toString = " + dispositivoBluetooth);
        Log.d(ETIQUETA_LOG, " dirección = " + dispositivoBluetooth.getAddress());
        Log.d(ETIQUETA_LOG, " rssi = " + rssi);
        Log.d(ETIQUETA_LOG, " bytes = " + new String(bytes));
        Log.d(ETIQUETA_LOG, " bytes (" + bytes.length + ") = "
                + Utilidades.bytesToHexString(bytes));
        Log.d(ETIQUETA_LOG, " ----------------------------------------------------");
        Log.d(ETIQUETA_LOG, " prefijo  = " + Utilidades.bytesToHexString(trama.getPrefijo()));
        Log.d(ETIQUETA_LOG, "          advFlags = " + Utilidades.bytesToHexString(trama.getAdvFlags()));
        Log.d(ETIQUETA_LOG, "          advHeader = " + Utilidades.bytesToHexString(trama.getAdvHeader()));
        Log.d(ETIQUETA_LOG, "          companyID = " + Utilidades.bytesToHexString(trama.getCompanyID()));
        Log.d(ETIQUETA_LOG, "          iBeacon type = "
                + Integer.toHexString(trama.getiBeaconType()));
        Log.d(ETIQUETA_LOG, "          iBeacon length 0x = "
                + Integer.toHexString(trama.getiBeaconLength()) + " ( "
                + trama.getiBeaconLength() + " ) ");
        Log.d(ETIQUETA_LOG, " uuid  = " + Utilidades.bytesToHexString(trama.getUUID()));
        Log.d(ETIQUETA_LOG, " uuid  = " + Utilidades.bytesToString(trama.getUUID()));
        Log.d(ETIQUETA_LOG, " major  = " + Utilidades.bytesToHexString(trama.getMajor()) + "( "
                + Utilidades.bytesToInt(trama.getMajor()) + " ) ");
        Log.d(ETIQUETA_LOG, " minor  = " + Utilidades.bytesToHexString(trama.getMinor()) + "( "
                + Utilidades.bytesToInt(trama.getMinor()) + " ) ");
        Log.d(ETIQUETA_LOG, " txPower  = " + Integer.toHexString(trama.getTxPower())
                + " ( " + trama.getTxPower() + " )");
        Log.d(ETIQUETA_LOG, " ****************************************************");

        // Major empaqueta tipo en el byte alto y contador en el bajo; Minor se interpreta con signo.
        if (tipoMedida == 11) {
            Log.d(ETIQUETA_LOG, "Servicio: CO2 = " + valor + " ppm (muestra " + contador + ")");
            enviarMedicionNueva("CO2", valor, tipoMedida, contador, dispositivoBluetooth.getAddress());
        } else if (tipoMedida == 12) {
            Log.d(ETIQUETA_LOG, "Servicio: temperatura = " + valor + " °C (muestra " + contador + ")");
            enviarMedicionNueva("TEMPERATURA", valor, tipoMedida, contador, dispositivoBluetooth.getAddress());
        }
    }

    /*
     * --------------------
     * tipo: Text, valor: Z, tipoMedida: N, contador: N --> enviarMedicionNueva() -->
     * Evita duplicados y delega la medición a lógica fake y REST.
     * --------------------
     */
    private void enviarMedicionNueva(String tipo, int valor, int tipoMedida, int contador, String dispositivoId) {
        if (ultimoTipoMedida == tipoMedida && ultimoContador == contador) {
            return;
        }
        ultimoTipoMedida = tipoMedida;
        ultimoContador = contador;
        try {
            LogicaFake.guardarMediciones(tipo, valor);
            PeticionarioREST.enviarMedicion(dispositivoId, tipo, valor);
        } catch (IllegalArgumentException error) {
            Log.e(ETIQUETA_LOG, "Medición descartada: " + error.getMessage());
        }
    }

    /*
     * --------------------
     * --> detenerEscaneo() -->
     * Detiene el escáner y libera el callback activo.
     * --------------------
     */
    private void detenerEscaneo() {
        if (elEscanner != null && callbackDelEscaneo != null) {
            elEscanner.stopScan(callbackDelEscaneo);
            callbackDelEscaneo = null;
        }
    }

    /*
     * --------------------
     * crearCanalNotificacion()
     * Crea el canal requerido por la notificación persistente.
     * --------------------
     */
    private void crearCanalNotificacion() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel canal = new NotificationChannel(
                    CANAL_ID, "Escucha de beacons", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(canal);
        }
    }

    /*
     * --------------------
     * --> iniciarPrimerPlano() -->
     * Muestra la notificación que mantiene el servicio en primer plano.
     * --------------------
     */
    private void iniciarPrimerPlano() {
        Notification.Builder creador = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CANAL_ID)
                : new Notification.Builder(this);
        Notification notificacion = creador
                .setContentTitle("Escuchando mediciones BLE")
                .setContentText("Buscando el beacon GTI-3A")
                .setSmallIcon(R.mipmap.ic_launcher)
                .build();
        startForeground(ID_NOTIFICACION, notificacion);
    }

    @Override
    /*
     * --------------------
     * onDestroy()
     * Detiene la escucha antes de destruir el servicio.
     * --------------------
     */
    public void onDestroy() {
        manejador.removeCallbacks(finBusquedaPrueba);
        detenerEscaneo();
        super.onDestroy();
    }

    @Override
    /*
     * --------------------
     * intent: Intent --> onBind() --> IBinder|Nulo
     * Indica que el servicio no ofrece vinculación directa.
     * --------------------
     */
    public IBinder onBind(Intent intent) {
        return null;
    }
}
