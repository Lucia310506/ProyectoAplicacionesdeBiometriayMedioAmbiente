// -*- mode: c++ -*-
/*
 * Fichero: Publicador.h
 * Autor: Lucía Díaz Murcia
 * Descripción: Esta clase publica los datos de temperatura y CO2 en un beacon.
 * Fecha: 2026-09-25
 * Copyright (c) 2026 Lucía Díaz Murcia
 */
// --------------------------------------------------------------
// Jordi Bataller i Mascarell
// --------------------------------------------------------------

#ifndef PUBLICADOR_H_INCLUIDO
#define PUBLICADOR_H_INCLUIDO

// --------------------------------------------------------------
// --------------------------------------------------------------
class Publicador {

  // ............................................................
  // ............................................................
private:

  uint8_t beaconUUID[16] = { 
	'E', 'P', 'S', 'G', '-', 'G', 'T', 'I', 
	'-', 'P', 'R', 'O', 'Y', '-', '3', 'A'
	};

  // ............................................................
  // ............................................................
public:
  EmisoraBLE laEmisora {
	"LuciaGTI", //  nombre emisora
	  0x004c, // fabricanteID (Apple)
	  4 // txPower
	  };
  
  const int RSSI = -53; // por poner algo, de momento no lo uso

  // ............................................................
  // ............................................................
public:

  // ............................................................
  // ............................................................
  enum MedicionesID  {
	CO2 = 11,
	TEMPERATURA = 12,
	RUIDO = 13,
	PRUEBA = 14
  };

  static constexpr int16_t VALOR_BEACON_PRUEBA = 0x5A3C; //Variable Beacon de pruebas.

  // ............................................................
  // ............................................................
  // --------------------
// Publicador()
// Prepara el beacon sin activar la radio durante la construcción.
// --------------------

  Publicador( ) {
	// ATENCION: no hacerlo aquí. (*this).laEmisora.encenderEmisora();
	// Pondremos un método para llamarlo desde el setup() más tarde
  } // ()

  // ............................................................
  // ............................................................
  // --------------------
// --> encenderEmisora() 
// Activa la emisora BLE una vez inicializada la placa.
// --------------------
  void encenderEmisora() {
	(*this).laEmisora.encenderEmisora();
  } // ()

  // ............................................................
  // ............................................................
  // --------------------
// valorCO2: N, contador: N, tiempoEspera: Z --> publicarCO2() -->
// Emite CO2 y detiene el anuncio al terminar el intervalo.
// --------------------
  void publicarCO2( int16_t valorCO2, uint8_t contador,
					long tiempoEspera ) {

	// 1. empezamos anuncio
	uint16_t major = (MedicionesID::CO2 << 8) + contador;
	(*this).laEmisora.emitirAnuncioIBeacon( (*this).beaconUUID, 
											major,
											valorCO2, // minor
											(*this).RSSI // rssi
									);

	/*
	Globales::elPuerto.escribir( "   publicarCO2(): valor=" );
	Globales::elPuerto.escribir( valorCO2 );
	Globales::elPuerto.escribir( "   contador=" );
	Globales::elPuerto.escribir( contador );
	Globales::elPuerto.escribir( "   todo="  );
	Globales::elPuerto.escribir( major );
	Globales::elPuerto.escribir( "\n" );
	*/

	// 2. esperamos el tiempo que nos digan
	esperar( tiempoEspera );

	// 3. paramos anuncio
	(*this).laEmisora.detenerAnuncio();
  } // ()

  // ............................................................
  // ............................................................
  // --------------------
// valorTemperatura:Z , contador: N, espera: N --> publicarTemperatura() -->
// Emite temperatura y detiene el anuncio al terminar el intervalo.
// --------------------

  void publicarTemperatura( int16_t valorTemperatura,
							uint8_t contador, long tiempoEspera ) {

	uint16_t major = (MedicionesID::TEMPERATURA << 8) + contador;
	(*this).laEmisora.emitirAnuncioIBeacon( (*this).beaconUUID, 
											major,
											valorTemperatura, // minor
											(*this).RSSI // rssi
									);
	esperar( tiempoEspera );

	(*this).laEmisora.detenerAnuncio();
  } // ()

  // --------------------
  // contador: N --> iniciarBeaconPrueba() -->
  // Anuncia un iBeacon con tipo PRUEBA y un valor centinela reconocible.
  // --------------------
  void iniciarBeaconPrueba( uint8_t contador ) {
	const uint16_t major = (MedicionesID::PRUEBA << 8) | contador;
	(*this).laEmisora.emitirAnuncioIBeacon(
	  (*this).beaconUUID,
	  major,
	  VALOR_BEACON_PRUEBA,
	  (*this).RSSI
	);
  }

  // --------------------
  // --> estaAnunciando() --> B
  // Devuelve el estado de emisión BLE para comprobar el beacon de prueba.
  // --------------------
  bool estaAnunciando() {
	return (*this).laEmisora.estaAnunciando();
  }

  // --------------------
  // --> detenerBeaconPrueba() -->
  // Detiene el anuncio BLE usado por la batería de pruebas.
  // --------------------
  void detenerBeaconPrueba() {
	(*this).laEmisora.detenerAnuncio();
  }
	
}; // class

// --------------------------------------------------------------
// --------------------------------------------------------------
// --------------------------------------------------------------
// --------------------------------------------------------------
#endif
