<?php
/*
 * Fichero: ConfiguracionProduccion.php
 * Autor: Lucía Díaz Murcia
 * Descripción: Credenciales privadas de la base de datos Plesk.
 * Fecha: 2026-09-25
 * Copyright (c) 2026 Lucía Díaz Murcia
 *
 * Este fichero está ignorado por Git y no debe compartirse ni subirse a repositorios.
 */

return [
    'host' => 'localhost',
    'base' => 'ldiamur_mediciones',
    'usuario' => 'ldm',
    'password' => 'Drac@rys26'
];
