<?php
/*
 * Fichero: ConfiguracionProduccion.ejemplo.php
 * Autor: Lucía Díaz Murcia
 * Descripción: Plantilla de credenciales Plesk. Copiar a ConfiguracionProduccion.php.
 * Fecha: 2026-09-25
 * Copyright (c) 2026 Lucía Díaz Murcia
 */
return [
    'host' => 'localhost',
    'base' => 'ldiamur_mediciones',
    'usuario' => 'ldm',
    'password' => 'Drac@rys26',
];
